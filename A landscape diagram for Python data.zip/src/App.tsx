import React, { useState } from 'react';
import { LandscapeDiagram } from './components/LandscapeDiagram';
import { DetailPanel } from './components/DetailPanel';
import { LayerTabs } from './components/LayerTabs';
import { LibraryNode } from './types/landscape';

function App() {
  const [selectedNode, setSelectedNode] = useState<LibraryNode | null>(null);
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [activeLayer, setActiveLayer] = useState<string | null>(null);

  const handleNodeClick = (node: LibraryNode) => {
    setSelectedNode(node);
    setIsPanelOpen(true);
  };

  const handlePanelClose = () => {
    setIsPanelOpen(false);
    setSelectedNode(null);
  };

  const handleLayerChange = (layer: string) => {
    setActiveLayer(layer);
  };

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <header className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Python Data Landscape Explorer
          </h1>
          <p className="text-gray-600">
            Interactive visualization of the Python data science ecosystem
          </p>
        </header>

        <LayerTabs activeLayer={activeLayer} onLayerChange={handleLayerChange} />
        
        <LandscapeDiagram 
          onNodeClick={handleNodeClick} 
          activeLayer={activeLayer}
        />

        <DetailPanel
          isOpen={isPanelOpen}
          onClose={handlePanelClose}
          selectedNode={selectedNode}
        />
      </div>
    </div>
  );
}

export default App;