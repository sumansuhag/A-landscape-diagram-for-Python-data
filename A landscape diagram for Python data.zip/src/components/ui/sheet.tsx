import React from 'react';
import { X } from 'lucide-react';

interface SheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: React.ReactNode;
}

interface SheetContentProps {
  side?: 'right' | 'left' | 'top' | 'bottom';
  className?: string;
  children: React.ReactNode;
}

interface SheetHeaderProps {
  className?: string;
  children: React.ReactNode;
}

interface SheetTitleProps {
  className?: string;
  children: React.ReactNode;
}

export const Sheet: React.FC<SheetProps> = ({ open, onOpenChange, children }) => {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div 
        className="absolute inset-0 bg-black/50" 
        onClick={() => onOpenChange(false)}
      />
      {children}
    </div>
  );
};

export const SheetContent: React.FC<SheetContentProps> = ({ side = 'right', className = '', children }) => {
  const positionClasses = {
    right: 'right-0 top-0 h-full',
    left: 'left-0 top-0 h-full',
    top: 'top-0 left-0 w-full',
    bottom: 'bottom-0 left-0 w-full'
  };

  return (
    <div className={`absolute ${positionClasses[side]} bg-white shadow-lg ${className}`}>
      {children}
    </div>
  );
};

export const SheetHeader: React.FC<SheetHeaderProps> = ({ className = '', children }) => {
  return <div className={`flex flex-col space-y-2 p-6 ${className}`}>{children}</div>;
};

export const SheetTitle: React.FC<SheetTitleProps> = ({ className = '', children }) => {
  return <h3 className={`text-lg font-semibold ${className}`}>{children}</h3>;
};