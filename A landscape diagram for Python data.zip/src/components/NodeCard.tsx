import React from 'react';
import { Card, CardContent } from '../components/ui/card';
import { LibraryNode } from '../types/landscape';

interface NodeCardProps {
  node: LibraryNode;
  scale: number;
  onClick: (node: LibraryNode) => void;
}

export const NodeCard: React.FC<NodeCardProps> = ({ node, scale, onClick }) => {
  return (
    <Card
      className={`
        absolute cursor-pointer transition-all duration-200 hover:scale-105 hover:shadow-md
        border-2 border-solid
      `}
      style={{
        left: `${node.x * 200 * scale}px`,
        top: `${node.y * 120 * scale}px`,
        width: `${180 * scale}px`,
        height: `${100 * scale}px`,
        backgroundColor: node.color,
        borderColor: node.color,
        transform: 'translateZ(0)'
      }}
      onClick={() => onClick(node)}
    >
      <CardContent className="p-3 flex items-center justify-center h-full">
        <div className="text-center">
          <h3 className={`font-semibold ${scale > 0.8 ? 'text-base' : 'text-sm'}`}>
            {node.name}
          </h3>
          <p className={`text-muted-foreground ${scale > 0.8 ? 'text-xs' : 'text-[10px]'}`}>
            {node.layer.replace('_', ' ')}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};