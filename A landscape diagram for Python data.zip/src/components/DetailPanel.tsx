import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '../components/ui/sheet';
import { LibraryNode } from '../types/landscape';
import { X } from 'lucide-react';

interface DetailPanelProps {
  isOpen: boolean;
  onClose: () => void;
  selectedNode: LibraryNode | null;
}

export const DetailPanel: React.FC<DetailPanelProps> = ({ isOpen, onClose, selectedNode }) => {
  if (!selectedNode) return null;

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="right" className="w-80 sm:w-96 bg-muted border-l">
        <SheetHeader className="flex flex-row items-center justify-between">
          <SheetTitle className="text-lg">{selectedNode.name}</SheetTitle>
          <button
            onClick={onClose}
            className="rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none"
          >
            <X className="h-4 w-4" />
          </button>
        </SheetHeader>
        
        <div className="mt-6 space-y-4">
          <div>
            <h4 className="text-sm font-medium text-muted-foreground">Layer</h4>
            <p className="text-sm capitalize">{selectedNode.layer.replace('_', ' ')}</p>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-muted-foreground">Description</h4>
            <p className="text-sm">{selectedNode.description}</p>
          </div>
          
          {selectedNode.relationships.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">Key Relationships</h4>
              <ul className="text-sm list-disc list-inside space-y-1">
                {selectedNode.relationships.map((rel, index) => (
                  <li key={index}>{rel}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};