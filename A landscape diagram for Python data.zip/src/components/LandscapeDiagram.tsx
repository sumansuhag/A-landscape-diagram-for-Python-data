import React, { useRef, useEffect, useState } from 'react';
import { NodeCard } from './NodeCard';
import { Connector } from './Connector';
import { LibraryNode } from '../types/landscape';
import { libraries, connections } from '../lib/landscapeData';

interface LandscapeDiagramProps {
  onNodeClick: (node: LibraryNode) => void;
  activeLayer: string | null;
}

export const LandscapeDiagram: React.FC<LandscapeDiagramProps> = ({ onNodeClick, activeLayer }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const updateScale = () => {
      if (containerRef.current) {
        const containerWidth = containerRef.current.clientWidth;
        const baseWidth = 1800; // Base width for the diagram
        const newScale = Math.min(1, containerWidth / baseWidth);
        setScale(newScale);
      }
    };

    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, []);

  useEffect(() => {
    if (activeLayer && containerRef.current) {
      const layerElement = containerRef.current.querySelector(`[data-layer="${activeLayer}"]`);
      if (layerElement) {
        layerElement.scrollIntoView({ behavior: 'smooth', inline: 'start' });
      }
    }
  }, [activeLayer]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-[600px] overflow-auto bg-white border rounded-lg"
    >
      <svg
        className="absolute inset-0 pointer-events-none"
        style={{ width: `${1800 * scale}px`, height: `${600 * scale}px` }}
      >
        {connections.map((conn, index) => (
          <Connector key={index} from={conn.from} to={conn.to} scale={scale} />
        ))}
      </svg>
      
      <div
        className="relative"
        style={{ width: `${1800 * scale}px`, height: `${600 * scale}px` }}
      >
        {libraries.map((node) => (
          <div
            key={node.id}
            data-layer={node.layer}
            className="absolute"
            style={{
              left: `${node.x * 200 * scale}px`,
              top: `${node.y * 120 * scale}px`,
              width: `${180 * scale}px`,
              height: `${100 * scale}px`
            }}
          >
            <NodeCard node={node} scale={scale} onClick={onNodeClick} />
          </div>
        ))}
      </div>
    </div>
  );
};