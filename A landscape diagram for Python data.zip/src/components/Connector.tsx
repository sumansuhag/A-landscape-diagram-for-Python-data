import React from 'react';
import { LibraryNode } from '../types/landscape';
import { libraries } from '../lib/landscapeData';

interface ConnectorProps {
  from: string;
  to: string;
  scale: number;
}

export const Connector: React.FC<ConnectorProps> = ({ from, to, scale }) => {
  const fromNode = libraries.find(lib => lib.id === from);
  const toNode = libraries.find(lib => lib.id === to);

  if (!fromNode || !toNode) return null;

  const fromX = fromNode.x * 200 * scale + 100 * scale;
  const fromY = fromNode.y * 120 * scale + 60 * scale;
  const toX = toNode.x * 200 * scale + 100 * scale;
  const toY = toNode.y * 120 * scale + 60 * scale;

  return (
    <line
      x1={fromX}
      y1={fromY}
      x2={toX}
      y2={toY}
      stroke="#e5e7eb"
      strokeWidth={1.5}
      strokeDasharray="4,4"
      className="opacity-60"
    />
  );
};